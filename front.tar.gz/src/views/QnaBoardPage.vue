<template>
    <div>
      <h1>QnA게시판</h1>
      <router-view></router-view>
    </div>
  </template>
  
  <script>
  export default {
    name: 'QnaBoardPage'
  };
  </script>
  
  <style scoped>
  /* 스타일은 필요에 따라 추가 */
  </style>
  