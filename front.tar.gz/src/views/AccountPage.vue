<template>
  <div>
    <h2>회계</h2>
    <p>매출</p>
    <p>매입</p>

  </div>
  <br>- 지출결의서 버튼 추가(양식)
  <br>- 사용 내역
  <br>- 통계자료
  <br>- 수입입력 창 추가
  <br>- 월별 카렌더 추가
  
</template>

<script>
export default {
  name: 'SchedulePage'
};
</script>

<style scoped>
h2 {
  margin-bottom: 20px;
}
</style>
