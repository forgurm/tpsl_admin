<template>
  <div class="other-page">
    <div class="group-box">
      <div v-for="(exchange, index) in exchanges" :key="index" class="exchange-settings">
        <input type="checkbox" :id="exchange.name" v-model="exchange.selected" />
        <label :for="exchange.name">{{ exchange.name }}</label>
        <div class="api-settings" v-if="exchange.selected">
          <div>
            <label for="apiKey">레퍼럴 API 키:</label>
            <input type="text" v-model="exchange.apiKey" />
          </div>
          <div>
            <label for="secretKey">시크릿 키:</label>
            <input type="text" v-model="exchange.secretKey" />
          </div>
        </div>
      </div>
      <div class="buttons">
        <button @click="saveSettings">저장</button>
        <button @click="deleteSettings">삭제</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'OtherPage',
  data() {
    return {
      exchanges: [
        { name: '바이비트', selected: false, apiKey: '', secretKey: '' },
        { name: '빙엑스', selected: false, apiKey: '', secretKey: '' }
        // 추가 거래소 데이터를 여기에 입력하세요
      ]
    };
  },
  methods: {
    saveSettings() {
      // 설정 저장 로직을 여기에 추가하세요
      console.log('Settings saved', this.exchanges);
      alert('설정이 저장되었습니다.');
    },
    deleteSettings() {
      // 설정 삭제 로직을 여기에 추가하세요
      this.exchanges.forEach(exchange => {
        exchange.selected = false;
        exchange.apiKey = '';
        exchange.secretKey = '';
      });
      console.log('Settings deleted', this.exchanges);
      alert('설정이 삭제되었습니다.');
    }
  }
};
</script>

<style scoped>

h2 {
  margin-bottom: 20px;
}

.group-box {
  padding: 20px;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #f9f9f9;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.exchange-settings {
  margin-bottom: 10px;
}

.api-settings {
  margin-left: 20px;
  margin-top: 10px;
}

.api-settings div {
  margin-bottom: 5px;
}

label {
  margin-right: 10px;
}

input[type="text"] {
  width: 300px;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

.buttons {
  margin-top: 20px;
}

button {
  padding: 10px 20px;
  border: none;
  border-radius: 3px;
  cursor: pointer;
  margin-right: 10px;
}

button:hover {
  background-color: #ddd;
}
</style>
