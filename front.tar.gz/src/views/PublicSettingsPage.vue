<template>
  <div class="settings-page">
    <router-view></router-view> <!-- 하위 라우트를 렌더링하기 위한 router-view -->
  </div>
</template>

<script>
export default {
  name: 'PublicSettingsPage'
};
</script>

