import axios from 'axios';

const state = {
  bots: [],
  errorLogs: [],
  botSettings: {},
  token: localStorage.getItem('token') || '' // 로컬 스토리지에서 토큰을 가져옴
};

const getters = {
  bots: state => state.bots,
  errorLogs: state => state.errorLogs,
  botSettings: state => state.botSettings
};

const mutations = {
  setBots(state, bots) {
    state.bots = bots;
  },
  setErrorLogs(state, errorLogs) {
    state.errorLogs = errorLogs;
  },
  setBotSettings(state, { botId, settings }) {
    state.botSettings = { ...state.botSettings, [botId]: settings };
  },
  setToken(state, token) {
    state.token = token;
    localStorage.setItem('token', token); // 로컬 스토리지에 토큰을 저장
  }
};

const actions = {
  async fetchBots({ commit, state }) {
    try {
      const response = await axios.get('/bot/bots', {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      commit('setBots', response.data);
    } catch (error) {
      console.error('Error fetching bots:', error);
    }
  },
  async fetchErrorLogs({ commit, state }) {
    try {
      const response = await axios.get('/bot/bot-error-logs', {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      commit('setErrorLogs', response.data);
    } catch (error) {
      console.error('Error fetching error logs:', error);
    }
  },
  async restartBot({ dispatch, state }, botId) {
    try {
      await axios.post(`/bot/bots/${botId}/restart`, null, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      dispatch('fetchBots');
      console.log(`Bot ${botId} 재시동`);
    } catch (error) {
      console.error(`Bot ${botId} 재시동 중 오류가 발생했습니다:`, error);
    }
  },
  async stopBot({ dispatch, state }, botId) {
    try {
      await axios.post(`/bot/bots/${botId}/stop`, null, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      dispatch('fetchBots');
      console.log(`Bot ${botId} 중지`);
    } catch (error) {
      console.error(`Bot ${botId} 중지 중 오류가 발생했습니다:`, error);
    }
  },
  async loadBotSettings(botId) {
    console.log('Loading settings for bot:', botId);
    const token = this.$store.state.token;
    try {
      const response = await axios.get(`/bot/bot-settings/${botId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('Loaded settings:', response.data);
      this.$set(this.botSettings, botId, response.data);
    } catch (error) {
      console.error('Failed to load bot settings', error);
    }
  },
  async saveSettings(botId) {
    console.log('Saving settings for bot:', botId);
    const token = this.$store.state.token;
    try {
      await axios.post(`/bot/bot-settings/${botId}`, this.botSettings[botId], {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log(`Settings saved for bot ${botId}:`, this.botSettings[botId]);
      this.showSettingsForBot = null;
    } catch (error) {
      console.error('Failed to save bot settings', error);
    }
  },
  cancelSettings(botId) {
    this.botSettings[botId] = { ...this.originalSettings[botId] };
    this.showSettingsForBot = null;
  },
  async fetchInitialData() {
    console.log('Fetching initial data');
    try {
      await this.fetchBots();
      await this.fetchErrorLogs();
    } finally {
      this.loading = false;
    }
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
