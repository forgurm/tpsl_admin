import axios from 'axios';


const state = {
  exchanges: [],
};

const getters = {
  exchanges: state => state.exchanges,
};

const mutations = {
  setExchanges(state, exchanges) {
    state.exchanges = exchanges;
  },
  updateSymbolName(state, { exchangeIndex, symbolIndex, newName }) {
    state.exchanges[exchangeIndex].symbols[symbolIndex].symbol_name = newName;
  },
};
console.log('load symbol.js')
const actions = {
  
  async fetchExchangeInfo({ commit, rootState }) {
    try {
      console.log('fetchExchangeInfo action called');
      const response = await axios.get('/api/symbol/exchange-info', {
        headers: { 'Authorization': `Bearer ${rootState.auth.token}` },
      });
      const filteredData = response.data.filter(symbol => !symbol.symbol_code.endsWith('USDT'));
      const groupedData = filteredData.reduce((result, currentValue) => {
        (result[currentValue.exchange_name] = result[currentValue.exchange_name] || []).push(currentValue);
        return result;
      }, {});
      const exchanges = Object.keys(groupedData).map(key => ({
        exchange_name: key,
        symbols: groupedData[key],
      }));
      commit('setExchanges', exchanges);
    } catch (error) {
      console.error('Error fetching exchange info:', error);
    }
  },
  async fetchExchangeSummary({ commit, rootState }) {
    try {
      console.log('fetchExchangeSummary action called');
      const response = await axios.get('/api/symbol/exchange-info-summary', {
        headers: { 'Authorization': `Bearer ${rootState.auth.token}` },
      });
      commit('setExchanges', response.data);
    } catch (error) {
      console.error('Error fetching exchange info summary:', error);
    }
  },
  async updateAllSymbols({ state, rootState }) {
    try {
      console.log('updateAllSymbols action called');
      const symbolsToUpdate = state.exchanges.flatMap(exchange => exchange.symbols);
      await axios.post('/api/symbol/update-symbols', symbolsToUpdate, {
        headers: { 'Authorization': `Bearer ${rootState.auth.token}` },
      });
      alert('Symbols updated successfully');
    } catch (error) {
      console.error('Error updating symbols:', error);
      alert('Failed to update symbols');
    }
  },
  async updateSelectedExchangeSymbols({ state, rootState }, selectedIndex) {
    try {
      console.log('updateSelectedExchangeSymbols action called');
      const symbolsToUpdate = state.exchanges[selectedIndex].symbols;
      await axios.post('/api/symbol/update-symbols', symbolsToUpdate, {
        headers: { 'Authorization': `Bearer ${rootState.auth.token}` },
      });
      alert('Selected exchange symbols updated successfully');
    } catch (error) {
      console.error('Error updating selected exchange symbols:', error);
      alert('Failed to update selected exchange symbols');
    }
  },
};

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions,
};
