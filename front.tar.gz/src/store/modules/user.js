import axios from 'axios';

const state = {
  members: []
};

const getters = {
  members: state => state.members
};

const mutations = {
  setMembers(state, members) {
    state.members = members;
  },
  addMember(state, member) {
    state.members.push(member);
  },
  editMember(state, updatedMember) {
    const index = state.members.findIndex(member => member.username === updatedMember.username);
    if (index !== -1) {
      state.members.splice(index, 1, updatedMember);
    }
  },
  deleteMember(state, username) {
    state.members = state.members.filter(member => member.username !== username);
  }
};

const actions = {
  async fetchMembers({ commit, state }) {
    try {
      const response = await axios.get('/user/members', {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      commit('setMembers', response.data);
    } catch (error) {
      console.error('Error fetching members:', error);
    }
  },
  async addMemberAction({ commit, state }, newMember) {
    try {
      console.log('Adding member:', newMember);  // 로그 추가
      const response = await axios.post('/user/add-member', newMember, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      console.log('Response from server:', response.data);  // 로그 추가
      if (response.data.success) {
        commit('addMember', newMember);
      }
      return response.data;
    } catch (error) {
      console.error('Error adding member:', error);  // 상세 로그 추가
      return { success: false, message: 'Failed to add member' };
    }
  },
  async editMemberAction({ commit, state }, updatedMember) {
    try {
      const response = await axios.put('/user/edit-member', updatedMember, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      if (response.data.success) {
        commit('editMember', updatedMember);
      }
      return response.data;
    } catch (error) {
      console.error('Error editing member:', error);
      return { success: false, message: 'Failed to edit member' };
    }
  },
  async deleteMemberAction({ commit, state }, username) {
    try {
      const response = await axios.delete(`/user/delete-member/${username}`, {
        headers: { 'Authorization': `Bearer ${state.token}` }
      });
      if (response.data.success) {
        commit('deleteMember', username);
      }
      return response.data;
    } catch (error) {
      console.error('Error deleting member:', error);
      return { success: false, message: 'Failed to delete member' };
    }
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
