import axios from 'axios';

const state = {
  token: localStorage.getItem('token') || ''
};

const getters = {
  isLoggedIn: state => !!state.token
};

const mutations = {
  setToken(state, token) {
    state.token = token;
  }
};
console.log('login')
const actions = {
  async login({ commit }, user) {
    try {
      const response = await axios.post('/auth/login', user);
      if (response.data.success) {
        const token = response.data.token;
        localStorage.setItem('token', token);
        commit('setToken', token);
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error('Error during login:', error);
      return false;
    }
  },
  logout({ commit }) {
    commit('setToken', '');
    localStorage.removeItem('token');
  }
};

export default {
  state,
  getters,
  mutations,
  actions
};
