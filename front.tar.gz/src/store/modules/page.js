// store/modules/page.js
const state = {
    title: 'Dashboard'
  };
  
  const mutations = {
    SET_PAGE_TITLE(state, title) {
      state.title = title;
    }
  };
  
  const actions = {
    updatePageTitle({ commit }, title) {
      commit('SET_PAGE_TITLE', title);
    }
  };
  
  const getters = {
    pageTitle: state => state.title
  };
  
  export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
  };
  